The .scss (Sass) files are only available in the pro version.-1
You can buy it from: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/